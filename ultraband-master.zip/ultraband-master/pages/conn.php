<?php
$localhost = "localhost";
$username = "root";
$password = "abcd@1234";
$database = "ultrabandsm";
$mysqli = new mysqli('localhost', 'root', 'abcd@1234','ultrabandsm') or die("Invalid connection");
?>



